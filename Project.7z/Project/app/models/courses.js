let mongoose = require("mongoose");
let Schema = mongoose.Schema;

let courseSchema = new Schema({
    courseCode: String,
    subjectCode: String,
    level: String,
    progression: String,
    name: String,
    points: Number,
    institutionCode: String
});

module.exports = mongoose.model("Courses", courseSchema);