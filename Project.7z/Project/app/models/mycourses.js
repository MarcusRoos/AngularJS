let mongoose = require("mongoose");
let Schema = mongoose.Schema;

let mycourseSchema = new Schema({
    courseCode: String,
    completed: String
});

module.exports = mongoose.model("my-courses", mycourseSchema);