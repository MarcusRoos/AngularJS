// Importera
const mongoose = require("mongoose");
// mongoose.connect("mongodb://localhost:27017/my-courses", {useNewUrlParser: true, useUnifiedTopology: true});
 mongoose.connect("mongodb+srv://dbUser:dbUserPassword@dt162g.zks4j.mongodb.net/my-courses?retryWrites=true&w=majority", {useNewUrlParser: true, useUnifiedTopology: true}); 
// Comment in above to use the local connection (faster response time than cloud), also comment out the cloud connection instead.
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");

// Skapa en instans av express
const app = express();

let Roster = require("./app/models/roster.js");
let Guild = require("./app/models/guild.js");

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));

app.all('/*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin, Accept, X-Requested-With, Content-Type");
  res.header("Access-Control-Allow-Methods", "GET,PUT,PATCH,POST,DELETE");
  next();
});


// Body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Port för anslutning
const port = process.env.PORT || 3000;
// Skapa statisk sökväg
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/roster', function (req, res) {

Roster.aggregate([
    {
       $lookup: {
          from: Guild.collection.name,
          localField: "name",   
          foreignField: "name",  
          as: "fromItems"
       }
    },
    {
       $replaceRoot: { newRoot: { $mergeObjects: [ { $arrayElemAt: [ "$fromItems", 0 ] }, "$$ROOT" ] } }
    }, 
    { $project: { rank:0 } }
 ]).exec(function(err, Roster){
    res.json(Roster);
 });

});

app.get('/api/guild', function (req, res) {
  Guild.aggregate([
    {
       $lookup: {
          from: Roster.collection.name,
          localField: "name",   
          foreignField: "name",  
          as: "fromItems"
       }
    },
    {
       $replaceRoot: { newRoot: { $mergeObjects: [ { $arrayElemAt: [ "$fromItems", 0 ] }, "$$ROOT" ] } }
    },
    { $project: { active:0, TBC:0, value:0, country:0 } }
 ]).exec(function(err, Guild){
    res.json(Guild);
 });
});

app.get('/api/roster/:name', function (req, res) {
  Roster.find({ name: req.params.name }, function(err, Rosters) {
    if (err){
      res.send(err);
    }
    res.json(Roster);
  });
});


app.get('/api/guild/:name', function (req, res) {
  Guild.find({ name: req.params.name }, function(err, Guild) {
    if (err){
      res.send(err);
    }
    res.json(Guild);
  });
});


app.post('/api/guild/add', function (req, res) {
  boolGuild = true;
  boolRoster = false;
  const tmpReliable = req.body.reliable;
    let tmpString = "";
    if (req.body.reliable == true){
      tmpString == "YES";
    }
    else{
      tmpString == "NO";
    }

    let newName = new guild();
    const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));
    newName.name = req.body.name;
    newName.reliable = tmpReliable;
    guild.exists({ name: req.body.name }, function(err, result) {
      if(err){
        console.log(err);
      } 
      else{
        if (result == true){
          boolGuild = true;
        }
        else if (result == false){
          boolGuild = false;
        }       
      }
  });

  Roster.exists({ name: req.body.name }, function(err, result) {
    if(err){
      console.log(err);
    } 
    else{
      if (result == true){
        boolRoster = true;
      }
      else if (result == false){
        boolRoster = false;
      }       
    }
});

sleep(300).then(() => {
  if (boolRoster){
    console.log("Name already exists, modify it instead.")
  };

  if (!boolRoster){
    console.log("Name doesn't exist.")
  };

    if (!boolRoster && boolGuild){
      newName.save(function(err){
        if (err){
          res.send(err);
        }
      });
    }
  res.redirect("/");
  });
});

app.put("/api/guild/:name", async (req, res, next)=>{
  tmpBool = "";
  await guild.findOne({
    name: req.params.name
}, (err, guild) => { 
  tmpBool = guild.reliable;
  
});
if (tmpBool == "YES"){
  await guild.findOneAndUpdate({ name: req.params.name }, { $set: { reliable: "NO" } }, { new: true }, function(err, doc) {
  });
}
  if (tmpBool == "NO"){
  await guild.findOneAndUpdate({ name: req.params.name }, { $set: { reliable: "YES" } }, { new: true }, function(err, doc) {
  });
}


  res.redirect("/");
});


app.delete('/api/guild/:name', function (req, res) {
  let tmpName = req.params.name;
  guild.deleteOne({
    name: tmpName
  }, function(err, guild){
    if(err){
      res.send(err)
    }
  
      res.json({message: "Deleted member " + tmpName});
    });
});

        
// Starta servern
app.listen(port, function() {
    console.log("Server running on port " + port);
  });